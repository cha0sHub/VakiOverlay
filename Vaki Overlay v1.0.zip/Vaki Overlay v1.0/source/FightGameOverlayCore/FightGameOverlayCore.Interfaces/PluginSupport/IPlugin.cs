﻿namespace FightGameOverlayCore.Interfaces.PluginSupport
{
    public interface IPlugin
    {

        void Start();
        void Shutdown();
    }
}
