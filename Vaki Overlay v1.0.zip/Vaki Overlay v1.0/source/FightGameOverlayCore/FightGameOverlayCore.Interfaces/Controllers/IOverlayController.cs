﻿namespace FightGameOverlayCore.Interfaces.Controllers
{
    public interface IOverlayController
    {
        void Display();
        void CloseWindow();
    }
}
