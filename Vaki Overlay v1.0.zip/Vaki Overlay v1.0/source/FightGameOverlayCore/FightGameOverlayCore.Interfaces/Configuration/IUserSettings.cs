﻿namespace FightGameOverlayCore.Interfaces.Configuration
{
    public interface IUserSettings
    {
        string CurrentLayout { get; set; }
    }
}