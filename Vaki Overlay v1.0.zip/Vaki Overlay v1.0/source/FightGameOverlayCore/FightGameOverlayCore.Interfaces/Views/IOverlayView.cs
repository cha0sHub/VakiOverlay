﻿namespace FightGameOverlayCore.Interfaces.Views
{
    public interface IOverlayView
    {
        void Display();
    }
}
