﻿namespace FightGameOverlayCore.Interfaces.Views
{
    public interface IDataManagerView
    {
        void Display();
    }
}
