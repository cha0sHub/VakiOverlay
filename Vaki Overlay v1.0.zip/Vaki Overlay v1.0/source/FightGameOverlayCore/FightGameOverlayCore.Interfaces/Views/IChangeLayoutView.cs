﻿namespace FightGameOverlayCore.Interfaces.Views
{
    public interface IChangeLayoutView
    {
        void Display();
        void CloseWindow();
    }
}
