﻿namespace FightGameOverlayCore.Interfaces.Views
{
    public interface ILayoutConfigurationView
    {
        void Display();
        void CloseWindow();
    }
}
